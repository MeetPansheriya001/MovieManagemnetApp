package ca.sheridancollege.pansheri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A3MeetPansheriyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
